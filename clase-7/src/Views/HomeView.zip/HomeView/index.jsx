/* Creara una vista que haga la conexion a dummpy json y traiga todos los post, y cree una instancia de postItem para cada uno. 

Hacer el refactor del componenete para que reciba los datos como propiedades en vez de tener una variable hardcodeada. 

10. 51*/

import Axios from 'axios';
import { useEffect, useState } from 'react';
import PostItem from '../../Components/PostItem';
import ScrollHorizontal from '../../Components/ScrollHorizontal';
import ScrollComentarios from '../../Components/ScrollComentarios';

function HomeView(){

    const [json, setJson] = useState({});
    const [cargando, setCargando] = useState(true);

    useEffect(()=>{
        Axios({url : `https://dummyjson.com/posts`})
        .then((response)=>{
            console.log(response.data.posts)
            setJson(response.data.posts)
            
            setCargando(false)
        })
        .catch((error)=>{
            console.log(error)
        })
    },[cargando])

    

    return (
        <div style={{display: "flex", }}>
            {
                cargando 
                ?
                    <p>Cargando, espere, por favor ...</p>
                :
                <ScrollHorizontal>
                    {json.map((post)=>(
                        <PostItem postData={post} />
                    ))}
                </ScrollHorizontal>
            }
            <ScrollComentarios idSeleccionado={4} />
        </div>
    )
}

export default HomeView;