import React, { useEffect, useState } from "react";
import Axios from 'axios';
import { useParams } from "react-router-dom";
// const id = 2
function DetalleDeProducto(){
    const {id} = useParams();
    const [json, setJson] = useState([]);
    const [login, setLogin] = useState(true);
    useEffect(()=>{
        Axios({
            url : `https://dummyjson.com/products/${id}`
        })
        .then((response)=>{
            setJson(response.data)
            setLogin(false)
        })
        .catch((error)=>{
            console.log(error)
        })
    },[login]);
    
    return(
        <React.Fragment>
                
                {
                login ? 
                <p> Cargando </p>
                :
                <div>
                    <h1> DetalleDeProducto del producto {json.title} </h1>
                    <p> {json.description} </p>
                    <h1> ${json.price} </h1>
                    {json.images.map((i, index)=>{
                        return (<img src={i} alt={`img-${index}`} style={{height:60}} />)
                    })}
                </div>
                }
        </React.Fragment>
    )
}

export default DetalleDeProducto;