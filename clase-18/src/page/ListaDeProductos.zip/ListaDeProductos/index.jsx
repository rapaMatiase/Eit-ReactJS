import { Link, NavLink } from "react-router-dom";

function ListaDeProductos(){


    return(
        <div>
            <h1> Lista de productos </h1>
            <NavLink to="/detalle/3"
                    title="Producto" > Ir al 3 </NavLink>
            <NavLink to="/detalle/4"
                    title="Producto" > Ir al 4 </NavLink>
            <NavLink to="/detalle/5"
                    title="Producto" > Ir al 5 </NavLink>
        </div>
    )
}

export default ListaDeProductos;