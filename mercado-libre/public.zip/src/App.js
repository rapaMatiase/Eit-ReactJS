import './App.css';
import TarjetaItem from './Components/TarjetaItem';

function App() {
  return (
    <div className="App">
      <TarjetaItem />
    </div>
  );
}

export default App;
