import { useState } from "react";

/* NOS OLVIDAMOS UN RATO DEL LOCAL STORAGE */
function UseCarritoDeCompras(){

    const [carrito, setCarrito] = useState([]);

    
    const agregarItem = (Item) => {
        /* Parte 1 - Agregar el item.  */
    }

    return [
        carrito,
        agregarItem,
        // quitarItem,
    ];
}

export default UseCarritoDeCompras;