import './App.css';
import MainView from './Views/Main';

function App() {
  return (
    <div className="App">
      <MainView />
    </div>
  );
}

export default App;
